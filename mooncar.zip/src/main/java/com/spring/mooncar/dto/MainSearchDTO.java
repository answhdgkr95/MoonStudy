package com.spring.mooncar.dto;

public class MainSearchDTO {
	String search_option;
	String search_customer;
	
	public String getSearch_option() {
		return search_option;
	}
	public void setSearch_option(String search_option) {
		this.search_option = search_option;
	}
	public String getSearch_customer() {
		return search_customer;
	}
	public void setSearch_customer(String search_customer) {
		this.search_customer = search_customer;
	}
	
	
}
