package com.spring.mooncar.dto;

public class Check_searchDTO {
	String[] fuel;
	String[] oil;
	String[] size;
	String[] type;
			
	public String[] getFuel() {
		return fuel;
	}
	public void setFuel(String[] fuel) {
		this.fuel = fuel;
	}
	public String[] getOil() {
		return oil;
	}
	public void setOil(String[] oil) {
		this.oil = oil;
	}
	public String[] getSize() {
		return size;
	}
	public void setSize(String[] size) {
		this.size = size;
	}
	public String[] getType() {
		return type;
	}
	public void setType(String[] type) {
		this.type = type;
	}
	
}
