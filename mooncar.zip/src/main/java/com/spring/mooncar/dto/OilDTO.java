package com.spring.mooncar.dto;

public class OilDTO {
	int o_number;
	String o_name;
	int o_km;
	int o_date;
	
	public int getO_number() {
		return o_number;
	}
	public void setO_number(int o_number) {
		this.o_number = o_number;
	}
	public String getO_name() {
		return o_name;
	}
	public void setO_name(String o_name) {
		this.o_name = o_name;
	}
	public int getO_km() {
		return o_km;
	}
	public void setO_km(int o_km) {
		this.o_km = o_km;
	}
	public int getO_date() {
		return o_date;
	}
	public void setO_date(int o_date) {
		this.o_date = o_date;
	}

}
