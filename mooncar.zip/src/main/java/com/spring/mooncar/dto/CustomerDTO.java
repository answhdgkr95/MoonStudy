package com.spring.mooncar.dto;

public class CustomerDTO {
	String c_tel;
	String c_name;
	int c_gender;
	String c_email;
	String c_comment;
	String c_email1;
	String c_email2;
	
	public String getC_email1() {
		return c_email1;
	}
	public void setC_email1(String c_email1) {
		this.c_email1 = c_email1;
	}
	public String getC_email2() {
		return c_email2;
	}
	public void setC_email2(String c_email2) {
		this.c_email2 = c_email2;
	}
	
	public String getC_tel() {
		return c_tel;
	}
	public void setC_tel(String c_tel) {
		this.c_tel = c_tel;
	}
	public String getC_name() {
		return c_name;
	}
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}
	public int getC_gender() {
		return c_gender;
	}
	public void setC_gender(int c_gender) {
		this.c_gender = c_gender;
	}
	public String getC_email() {
		return c_email;
	}
	public void setC_email(String c_email) {
		this.c_email = c_email;
	}
	public String getC_comment() {
		return c_comment;
	}
	public void setC_comment(String c_comment) {
		this.c_comment = c_comment;
	}
	
}
