package com.spring.mooncar.dto;

public class CarDTO {
	String car_number;
	String c_tel;
	String car_name;
	int car_km;
	String car_maker;
	String car_size;
	String car_category;
	String car_fuel_type;
	String car_oil_type;
	int car_oil_date;
	String car_comment;
	String c_name;
	String c_email;
	public String getCar_number() {
		return car_number;
	}
	public void setCar_number(String car_number) {
		this.car_number = car_number;
	}
	public String getC_tel() {
		return c_tel;
	}
	public void setC_tel(String c_tel) {
		this.c_tel = c_tel;
	}
	public String getCar_name() {
		return car_name;
	}
	public void setCar_name(String car_name) {
		this.car_name = car_name;
	}
	public int getCar_km() {
		return car_km;
	}
	public void setCar_km(int car_km) {
		this.car_km = car_km;
	}
	public String getCar_maker() {
		return car_maker;
	}
	public void setCar_maker(String car_maker) {
		this.car_maker = car_maker;
	}
	public String getCar_size() {
		return car_size;
	}
	public void setCar_size(String car_size) {
		this.car_size = car_size;
	}
	public String getCar_category() {
		return car_category;
	}
	public void setCar_category(String car_category) {
		this.car_category = car_category;
	}
	public String getCar_fuel_type() {
		return car_fuel_type;
	}
	public void setCar_fuel_type(String car_fuel_type) {
		this.car_fuel_type = car_fuel_type;
	}
	public String getCar_oil_type() {
		return car_oil_type;
	}
	public void setCar_oil_type(String car_oil_type) {
		this.car_oil_type = car_oil_type;
	}
	public int getCar_oil_date() {
		return car_oil_date;
	}
	public void setCar_oil_date(int car_oil_date) {
		this.car_oil_date = car_oil_date;
	}
	public String getCar_comment() {
		return car_comment;
	}
	public void setCar_comment(String car_comment) {
		this.car_comment = car_comment;
	}
	public String getC_name() {
		return c_name;
	}
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}
	public String getC_email() {
		return c_email;
	}
	public void setC_email(String c_email) {
		this.c_email = c_email;
	}
	
}
