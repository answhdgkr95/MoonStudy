package com.hwyj.domain;

import lombok.Data;

@Data
public class AuthVO {
	
	private String id; //아이디
	private String auth; //권한

}
